A Pen created at CodePen.io. You can find this one at https://codepen.io/dallasmcfly/pen/NoPdVx.

 Shining text effect by using css transforms.
* Move pointer on the page to change angle.
* Texts are editable.

* Because codepen doesn't support device orientation event for security reason, You can see this with device orientation at http://play.psyonline.kr/pages/shining-text/ :)